Use these starting files for your assignments. Use this index page as the home page for any assignment folder.
